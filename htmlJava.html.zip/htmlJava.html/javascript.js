
    //String
    var marcaVeiculo = "FIAT CRONOS";
    //Inteiro
    var anoVeiculo = 2022;
    //Inteiro
    var kmVeiculo = 12.436;
    //Float
    var valorVeiculo = 75.992;

    console.log(marcaVeiculo);
    console.log(anoVeiculo);
    console.log(kmVeiculo);
    console.log(valorVeiculo);

console.log(" ");




var a =30;
var b =50;

c = a + b;

console.log(c);



var a =30;
var b =50;

c = a - b;

console.log(c);



var a =30;
var b =50;

c = a * b;

console.log(c);



var a =30;
var b =50;

c = a ** b;

console.log(c);



var a =30;
var b =50;

c = a / b;

console.log(c);



var a =14;
var b =10;

c = a % b;

console.log(c);



var a =14;
var b =10;

c = a - b;
c++;

console.log(c);