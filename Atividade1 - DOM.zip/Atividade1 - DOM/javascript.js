// Alterar o estilo da fonte das divs
const divs = document.querySelectorAll('.classe1, .classe2, .classe3');

divs.forEach(div => {
  const titulo = div.querySelector('h1');
  const paragrafo = div.querySelector('p');
  
  titulo.style.fontSize = '24px';
  paragrafo.style.fontSize = '16px';
});

// Alterar a cor de fundo de uma das divs
const divComFundoColorido = document.querySelector('.classe2');
divComFundoColorido.style.backgroundColor = 'lightblue';
