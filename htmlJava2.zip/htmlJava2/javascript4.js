//4

function encontrarMenorNumero() {
    const numeros = [];
    for (let i = 0; i < 5; i++) {
        const numero = parseInt(prompt(`Digite o número ${i + 1}:`));
        numeros.push(numero);
    }

    const menorNumero = Math.min(...numeros);
    return menorNumero;
  }

  const menorNumeroEncontrado = encontrarMenorNumero();
  console.log("O menor número é: " + menorNumeroEncontrado);

  
  console.log(" ");
