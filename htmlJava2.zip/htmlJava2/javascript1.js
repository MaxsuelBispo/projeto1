//1

const carros = [
    "Ferrari",
    "Tesla",
    "BMW",
    "Toyota",
    "Honda",
    "Ford",
    "Chevrolet",
    "Mercedes",
    "Nissan",
    "Audi",
    "Lamborghini",
    "Volkswagen",
    "Hyundai",
    "Kia",
    "Subaru",
    "Volvo",
    "Porsche",
    "Mazda",
    "Lexus",
    "Jeep"
  ];

  for (let i = 0; i < carros.length; i++) {
    console.log(carros[i]);
  }


  console.log(" ");

