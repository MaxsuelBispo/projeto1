//2

const numeros = [];

for (let i = 0; i < 10; i++) {
  const numero = parseInt(prompt(`Digite o número ${i + 1}:`));
  numeros[i] = numero;
}

function imprimirNumeros(numeros) { // Adicione 'numeros' como parâmetro
  console.log("Números inseridos: " + numeros.join(", "));
  numeros.sort((a, b) => a - b);
  console.log("Números em ordem crescente: " + numeros.join(", "));
}

console.log(" ");

imprimirNumeros(numeros); // Chama a função e passa o array 'numeros' como argumento
