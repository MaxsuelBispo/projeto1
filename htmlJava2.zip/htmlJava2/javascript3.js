//3

function calcularMedia() {
    const numero1 = parseInt(prompt("Digite o primeiro número:"));
    const numero2 = parseInt(prompt("Digite o segundo número:"));
    const numero3 = parseInt(prompt("Digite o terceiro número:"));

    const media = (numero1 + numero2 + numero3) / 3;
    return media;
  }

  const mediaCalculada = calcularMedia();
  console.log("A média dos três é: " + mediaCalculada);


  console.log(" ");