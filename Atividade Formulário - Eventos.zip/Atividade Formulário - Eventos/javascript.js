function calcularResultado() {
    const numero1 = parseFloat(document.getElementById("numero1").value);
    const numero2 = parseFloat(document.getElementById("numero2").value);
    
    const operacao = document.querySelector('input[name="operacao"]:checked').value;
    
    let resultado;
    
    switch (operacao) {
        case "soma":
            resultado = numero1 + numero2;
            break;
        case "subtracao":
            resultado = numero1 - numero2;
            break;
        case "multiplicacao":
            resultado = numero1 * numero2;
            break;
        case "divisao":
            resultado = numero1 / numero2;
            break;
    }
    
    alert("O resultado da operação é: " + resultado);
    
    const mensagemCheckbox = document.getElementById("mensagemCheckbox");
    if (mensagemCheckbox.checked) {
        alert("O resultado da operação está correto?");
    }
}

const calcularButton = document.getElementById("calcularButton");
calcularButton.addEventListener("click", calcularResultado);
