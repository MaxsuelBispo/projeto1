// Função para exibir uma mensagem quando um item da lista for clicado
function exibirMensagem(item) {
    alert('Você clicou em: ' + item.textContent);
}

// Adiciona um evento de clique a todos os itens das classes "carro", "moto" e "barco"
var veiculoItems = document.querySelectorAll('.carro li, .moto li, .barco li');
veiculoItems.forEach(function(item) {
    item.addEventListener('click', function() {
        exibirMensagem(item);
    });
});

// Altera a cor do texto e adiciona uma borda azul aos itens de todas as classes
var veiculos = document.querySelectorAll('.carro, .moto, .barco');
veiculos.forEach(function(veiculo) {
    veiculo.style.color = 'blue';  // Altere para a cor desejada
    veiculo.style.border = '1px solid blue';  // Adiciona uma borda azul
});
